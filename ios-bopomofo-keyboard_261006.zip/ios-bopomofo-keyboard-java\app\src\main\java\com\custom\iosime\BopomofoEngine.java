package com.custom.iosime;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class BopomofoEngine {
    private static final String DB_EN = "dictionary.db";
    // 舊版中文資料庫：中文選字已改用 zhuyin_cedict.tsv，這裡只用來清掉舊安裝殘留在內部儲存的副本。
    private static final String LEGACY_DB_ZH = "phonetic.db";
    private SQLiteDatabase dbEn;
    private final Context context;

    // 聲調符號：ˉ 是一聲（空白鍵代表一聲時會補上），其餘四個是鍵盤上的聲調鍵
    public static final String FIRST_TONE = "ˉ";
    private static final String NEUTRAL_TONE = "˙";
    private static final int PREFIX_CANDIDATE_LIMIT = 18;
    private static final int CANDIDATE_CACHE_CAPACITY = 128;
    private static final Set<String> STANDALONE_FINALS = new HashSet<>(Arrays.asList(
            "ㄚ", "ㄛ", "ㄜ", "ㄝ", "ㄞ", "ㄟ", "ㄠ", "ㄡ",
            "ㄢ", "ㄣ", "ㄤ", "ㄥ", "ㄦ", "ㄧ", "ㄨ", "ㄩ"));

    // 選字學習（只在一般文字欄位開啟；密碼欄位、要求不學習的欄位會關閉）
    private volatile CandidateLearning learning;
    private boolean learningAllowed = false;
    private final Map<String, List<String>> sortedCandidateCache =
            new LinkedHashMap<String, List<String>>(CANDIDATE_CACHE_CAPACITY, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<String, List<String>> eldest) {
                    return size() > CANDIDATE_CACHE_CAPACITY;
                }
            };

    // 資料庫（尤其是複製 assets 到內部儲存這一步）絕對不能放在主執行緒做，
    // 否則在 onCreateInputView() 期間會擋住畫面顯示，導致系統認為輸入法沒有回應而直接退回上一個鍵盤
    // （在磁碟較慢的模擬器/VM 上特別容易發生：選鍵盤時直接跳掉、連畫面都沒顯示過）。
    // 所以這裡改成背景執行緒非同步初始化；初始化完成前，所有查詢方法都會安全地回傳空結果，
    // 不會讓鍵盤主體畫面等待資料庫，只有候選字會晚個一瞬間才「醒過來」。
    private volatile boolean ready = false;

    public BopomofoEngine(Context context) {
        this.context = context;
        new Thread(() -> {
            ZhuyinDictionary.initialize(context);
            initDatabases();
            NextWordTable.load(context);
            learning = new CandidateLearning(context);
            ready = true;
        }, "BopomofoEngine-init").start();
    }

    public boolean isReady() {
        return ready;
    }

    public void close() {
        try { if (dbEn != null) dbEn.close(); } catch (Exception e) {}
        try { if (learning != null) learning.close(); } catch (Exception e) {}
    }

    private void initDatabases() {
        try { context.deleteDatabase(LEGACY_DB_ZH); } catch (Exception ignored) {}
        copyAssetDb(DB_EN);
        try {
            dbEn = SQLiteDatabase.openDatabase(context.getDatabasePath(DB_EN).getPath(), null, SQLiteDatabase.OPEN_READONLY);
        } catch (Exception e) {}
    }

    private void copyAssetDb(String dbName) {
        File dbFile = context.getDatabasePath(dbName);
        long assetSize = -1;
        try {
            android.content.res.AssetFileDescriptor afd = context.getAssets().openFd(dbName);
            assetSize = afd.getLength();
            afd.close();
        } catch (Exception ignored) {}

        // 檔案不存在，或跟 assets 裡的大小對不起來（代表資料庫更新過），才需要重新複製；
        // 避免每次開鍵盤都重寫檔案，也避免舊安裝殘留的舊資料庫一直被誤用。
        boolean needsCopy = !dbFile.exists() || dbFile.length() < 1000
                || (assetSize > 0 && dbFile.length() != assetSize);

        if (needsCopy) {
            if (dbFile.getParentFile() != null) dbFile.getParentFile().mkdirs();
            try (InputStream is = context.getAssets().open(dbName);
                 FileOutputStream fos = new FileOutputStream(dbFile)) {
                byte[] buffer = new byte[16384];
                int read;
                while ((read = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, read);
                }
            } catch (Exception e) {}
        }
    }

    // ===================== 中文選字（搬運自 dynamic-zhuyin-keyboard） =====================

    /** 由輸入法在每次開始輸入時設定：密碼欄位等不應該記錄學習資料。 */
    public void setLearningAllowed(boolean allowed) {
        if (learningAllowed != allowed) sortedCandidateCache.clear();
        learningAllowed = allowed;
    }

    /**
     * 依目前整段注音回傳候選字。每個候選都帶有它「吃掉」的注音長度（從開頭算），
     * 選了之後剩下的注音會留著繼續選，例如整句候選、或只選第一個字。
     */
    public List<CandidateItem> getCandidates(String raw) {
        List<CandidateItem> list = new ArrayList<>();
        if (raw == null || raw.isEmpty() || !ZhuyinDictionary.isReady()) return list;
        ZhuyinComposition.Match match = ZhuyinComposition.resolveLeadingCandidates(
                raw,
                splitSegments(raw),
                reading -> Collections.<String>emptyList(), // 原專案這裡是「使用者自訂詞」，本鍵盤沒有該功能
                reading -> ZhuyinDictionary.getPrefixCandidates(reading, PREFIX_CANDIDATE_LIMIT),
                this::getSortedCandidates);
        if (match == null) return list;
        for (ZhuyinComposition.Choice c : match.choices) {
            list.add(new CandidateItem(c.text, c.end, raw.substring(c.start, c.end), c.provisional));
        }
        return list;
    }

    List<ZhuyinComposition.Segment> splitSegments(String raw) {
        return ZhuyinComposition.splitSegments(raw, this::isKnownUntonedSyllable);
    }

    private boolean isKnownUntonedSyllable(String value) {
        return STANDALONE_FINALS.contains(value) || ZhuyinDictionary.getCandidates(value) != null;
    }

    /** 最後一個音節是否已經有聲調（決定要顯示聲母頁還是韻母/聲調頁）。 */
    public boolean lastSegmentHasTone(String raw) {
        List<ZhuyinComposition.Segment> segments = splitSegments(raw);
        return !segments.isEmpty() && segments.get(segments.size() - 1).hasTone;
    }

    /** 對最後一個音節套用聲調；已經有聲調就替換掉（跟原專案相同）。 */
    public String applyToneToLastSegment(String raw, String tone) {
        List<ZhuyinComposition.Segment> segments = splitSegments(raw);
        if (segments.isEmpty()) return raw;
        ZhuyinComposition.Segment last = segments.get(segments.size() - 1);
        StringBuilder sb = new StringBuilder(raw);
        if (last.hasTone && last.end > last.start) sb.deleteCharAt(last.end - 1);
        sb.insert(last.hasTone ? last.end - 1 : last.end, tone);
        return sb.toString();
    }

    private List<String> getSortedCandidates(String raw) {
        List<String> cached = sortedCandidateCache.get(raw);
        if (cached != null) return cached;
        List<String> dictionaryCandidates = candidatesForKey(raw);
        CandidateLearning store = learning;
        if (!learningAllowed || store == null) {
            sortedCandidateCache.put(raw, dictionaryCandidates);
            return dictionaryCandidates;
        }
        List<String> readings = lookupVariants(raw);
        Map<String, Integer> counts;
        List<String> learned;
        try {
            counts = store.getLearningCounts(readings);
            learned = store.getLearnedCandidates(readings);
        } catch (Exception e) {
            counts = Collections.emptyMap();
            learned = Collections.emptyList();
        }
        List<String> result = (dictionaryCandidates.isEmpty() && learned.isEmpty())
                ? Collections.<String>emptyList()
                : CandidateLearning.order(Collections.<String>emptyList(), dictionaryCandidates, counts, learned);
        sortedCandidateCache.put(raw, result);
        return result;
    }

    private List<String> candidatesForKey(String raw) {
        LinkedHashSet<String> merged = new LinkedHashSet<>();
        for (String key : lookupVariants(raw)) {
            List<String> c = ZhuyinDictionary.getCandidates(key);
            if (c != null) merged.addAll(c);
        }
        return new ArrayList<>(merged);
    }

    private List<String> lookupVariants(String raw) {
        LinkedHashSet<String> variants = new LinkedHashSet<>();
        variants.add(raw);
        variants.add(markLastSegmentAsNeutralTone(raw));
        variants.add(stripTones(raw));
        variants.add(markUntonedSegmentsAsFirstTone(raw));
        List<String> out = new ArrayList<>();
        for (String v : variants) if (!v.isEmpty()) out.add(v);
        return out;
    }

    private static String stripTones(String raw) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            if (!ZhuyinComposition.isTone(c)) sb.append(c);
        }
        return sb.toString();
    }

    private String markUntonedSegmentsAsFirstTone(String raw) {
        List<ZhuyinComposition.Segment> segments = splitSegments(raw);
        if (segments.isEmpty()) return raw;
        StringBuilder sb = new StringBuilder();
        int cursor = 0;
        for (ZhuyinComposition.Segment s : segments) {
            if (cursor < s.start) sb.append(raw, cursor, s.start);
            sb.append(s.text);
            if (!s.hasTone) sb.append(FIRST_TONE);
            cursor = s.end;
        }
        if (cursor < raw.length()) sb.append(raw.substring(cursor));
        return sb.toString();
    }

    private String markLastSegmentAsNeutralTone(String raw) {
        List<ZhuyinComposition.Segment> segments = splitSegments(raw);
        if (segments.isEmpty()) return raw;
        ZhuyinComposition.Segment last = segments.get(segments.size() - 1);
        StringBuilder sb = new StringBuilder(raw);
        if (last.hasTone && last.end > last.start) {
            sb.deleteCharAt(last.end - 1);
            sb.insert(last.end - 1, NEUTRAL_TONE);
        } else {
            sb.insert(last.end, NEUTRAL_TONE);
        }
        return sb.toString();
    }

    /** 記錄「這個讀音選了這個字詞」，下次同讀音時會排得更前面。 */
    public void recordSelection(String reading, String word) {
        CandidateLearning store = learning;
        if (!learningAllowed || store == null || reading == null || reading.isEmpty()) return;
        try {
            store.recordSelection(reading, word);
            sortedCandidateCache.clear();
        } catch (Exception e) {
            android.util.Log.w("IosIME", "無法記錄選字學習", e);
        }
    }

    /** 記錄「previous 後面接了 word」，讓聯想詞也會學習。 */
    public void recordContinuation(String previous, String word) {
        CandidateLearning store = learning;
        if (!learningAllowed || store == null) return;
        if (!NextWordTable.eligible(previous) || !NextWordTable.eligible(word)) return;
        try {
            store.recordSelection(NextWordTable.learningKey(previous), word);
        } catch (Exception e) {
            android.util.Log.w("IosIME", "無法記錄聯想學習", e);
        }
    }

    /** 選完字後的「下一個詞」聯想；沒有可聯想的就給常用標點。 */
    public List<CandidateItem> getAssociationWords(String lastWord) {
        List<CandidateItem> list = new ArrayList<>();
        if (lastWord == null || lastWord.isEmpty() || !NextWordTable.eligible(lastWord)) return list;
        List<String> learned = Collections.emptyList();
        CandidateLearning store = learning;
        if (learningAllowed && store != null) {
            try {
                learned = store.getLearnedCandidates(Collections.singletonList(NextWordTable.learningKey(lastWord)));
            } catch (Exception ignored) {}
        }
        List<String> words = NextWordTable.suggest(lastWord, learned);
        if (words.isEmpty()) words = NextWordTable.PUNCTUATION_FALLBACK;
        for (String w : words) list.add(new CandidateItem(w, 0));
        return list;
    }

    // ===================== 英文字典（維持原本邏輯） =====================

    public List<CandidateItem> getEnglishCandidates(String prefix) {
        List<CandidateItem> list = new ArrayList<>();
        if (prefix == null || prefix.isEmpty()) return list;

        if (dbEn != null && dbEn.isOpen()) {
            try (Cursor cursor = dbEn.rawQuery(
                "SELECT word FROM dictionary_data WHERE word LIKE ? ORDER BY length(word) ASC, basescore DESC LIMIT 30",
                new String[]{ prefix.toLowerCase() + "%" })) {
                while (cursor.moveToNext()) {
                    String w = cursor.getString(0);
                    if (!containsWord(list, w)) list.add(new CandidateItem(w, prefix.length()));
                }
            } catch (Exception e) {}
        }
        return list;
    }

    private boolean containsWord(List<CandidateItem> list, String word) {
        for (CandidateItem item : list) {
            if (item.text.equals(word)) return true;
        }
        return false;
    }

    public static class CandidateItem {
        public String text;
        public int consumedLength;
        // 這個候選對應的注音讀音（用來記錄選字學習）；英文/emoji/聯想詞為 null
        public String reading;
        // 尚未打完的讀音所產生的暫定候選，不列入學習
        public boolean provisional;

        public CandidateItem(String text, int consumedLength) {
            this(text, consumedLength, null, false);
        }

        public CandidateItem(String text, int consumedLength, String reading, boolean provisional) {
            this.text = text;
            this.consumedLength = consumedLength;
            this.reading = reading;
            this.provisional = provisional;
        }
    }
}
