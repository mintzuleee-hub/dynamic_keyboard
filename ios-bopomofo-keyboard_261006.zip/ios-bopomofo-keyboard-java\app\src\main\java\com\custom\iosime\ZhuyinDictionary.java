package com.custom.iosime;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.os.ParcelFileDescriptor;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

/**
 * 注音字典（搬運自 dynamic-zhuyin-keyboard 的 ZhuyinDictionary / SortedTsvDictionary，改寫為 Java）。
 *
 * 資料來源：CC-CEDICT（CC BY-SA 4.0）與 McBopomofo 片語讀音／詞頻資料（MIT）。
 * 打包資產：assets/zhuyin_cedict.tsv，授權聲明見 assets/zhuyin_cedict_LICENSE.txt。
 *
 * 檔案每一列是「注音讀音<TAB>候選1 候選2 ...」，並依（字元數, 讀音）排序，
 * 所以可以直接在記憶體對映的 ByteBuffer 上二分搜尋，不需要把整本字典展開成物件。
 */
public final class ZhuyinDictionary {

    private static final String ASSET_NAME = "zhuyin_cedict.tsv";

    private static volatile SortedTsvDictionary dictionary;

    private ZhuyinDictionary() {}

    public static void initialize(Context context) {
        if (dictionary != null) return;
        synchronized (ZhuyinDictionary.class) {
            if (dictionary == null) {
                try {
                    dictionary = new SortedTsvDictionary(openAssetBuffer(context));
                } catch (IOException e) {
                    android.util.Log.e("IosIME", "無法載入注音字典 " + ASSET_NAME, e);
                }
            }
        }
    }

    public static boolean isReady() {
        return dictionary != null;
    }

    /** 精確讀音查詢；查不到回傳 null（跟原版一樣用 null 代表「沒有這個讀音」）。 */
    public static List<String> getCandidates(String key) {
        SortedTsvDictionary d = dictionary;
        return d == null ? null : d.getCandidates(key);
    }

    public static List<String> getPrefixCandidates(String prefix, int limit) {
        SortedTsvDictionary d = dictionary;
        return d == null ? Collections.<String>emptyList() : d.getPrefixCandidates(prefix, limit);
    }

    private static ByteBuffer openAssetBuffer(Context context) throws IOException {
        try (AssetFileDescriptor afd = context.getAssets().openFd(ASSET_NAME)) {
            ParcelFileDescriptor dup = ParcelFileDescriptor.dup(afd.getFileDescriptor());
            try (FileInputStream input = new ParcelFileDescriptor.AutoCloseInputStream(dup)) {
                return input.getChannel().map(FileChannel.MapMode.READ_ONLY, afd.getStartOffset(), afd.getLength());
            }
        } catch (IOException e) {
            // 被壓縮的 asset 無法 memory-map；build.gradle 已設定 tsv 不壓縮，這裡保留讀進記憶體的備援。
            try (InputStream input = context.getAssets().open(ASSET_NAME)) {
                ByteArrayOutputStream out = new ByteArrayOutputStream(1 << 20);
                byte[] buf = new byte[1 << 16];
                int n;
                while ((n = input.read(buf)) != -1) out.write(buf, 0, n);
                return ByteBuffer.wrap(out.toByteArray()).asReadOnlyBuffer();
            }
        }
    }

    /**
     * 低記憶體的 TSV 讀取器：所有列依（Unicode code point 數, 讀音）排序。
     * 查詢時直接在 ByteBuffer 上用二分搜尋找行界線，只把命中的那一列解碼成字串。
     */
    static final class SortedTsvDictionary {
        private static final int COMMENT = '#';
        private static final int SPACE = ' ';
        private static final int TAB = '\t';
        private static final int CARRIAGE_RETURN = '\r';
        private static final int LINE_FEED = '\n';
        private static final int MAX_PREFIX_MATCHING_ROWS = 64;
        private static final int MAX_PREFIX_CANDIDATES_PER_ROW = 4;
        private static final int LOOKUP_CACHE_CAPACITY = 256;

        private final ByteBuffer bytes;
        private final int byteCount;
        private final int dataStart;
        private volatile List<int[]> lengthRanges; // 每個元素：{codePointLength, start, endExclusive}

        private final Object cacheLock = new Object();
        private final Map<String, List<String>> candidateCache = lruMap();
        private final Map<String, List<String>> prefixCandidateCache = lruMap();

        SortedTsvDictionary(ByteBuffer source) {
            this.bytes = source.slice().asReadOnlyBuffer();
            this.byteCount = bytes.limit();
            this.dataStart = findDataStart();
        }

        private static <V> Map<String, V> lruMap() {
            return new LinkedHashMap<String, V>(LOOKUP_CACHE_CAPACITY, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<String, V> eldest) {
                    return size() > LOOKUP_CACHE_CAPACITY;
                }
            };
        }

        List<String> getCandidates(String key) {
            if (key == null || key.isEmpty()) return null;
            synchronized (cacheLock) {
                List<String> cached = candidateCache.get(key);
                if (cached != null) return cached.isEmpty() ? null : cached;
            }
            int[] line = findLine(key);
            List<String> candidates = line == null ? Collections.<String>emptyList() : candidatesInLine(line[0], line[1]);
            synchronized (cacheLock) {
                candidateCache.put(key, candidates);
            }
            return candidates.isEmpty() ? null : candidates;
        }

        /** 回傳讀音以 prefix 開頭的候選（有上限），排序依：最短讀音 → 出現次數 → 列內排名 → 首次出現。 */
        List<String> getPrefixCandidates(String prefix, int limit) {
            if (prefix == null || prefix.isEmpty() || limit <= 0) return Collections.emptyList();
            String cacheKey = prefix + '\u0000' + limit;
            synchronized (cacheLock) {
                List<String> cached = prefixCandidateCache.get(cacheKey);
                if (cached != null) return cached;
            }

            int prefixLength = prefix.codePointCount(0, prefix.length());
            LinkedHashMap<String, int[]> scores = new LinkedHashMap<>(); // {shortestLen, bestRank, firstSeen, appearances}
            int matchingRows = 0;
            int firstSeen = 0;

            for (int[] range : lengthRanges()) {
                if (range[0] < prefixLength) continue;
                Integer startObj = findFirstPrefixLine(prefix, range);
                if (startObj == null) continue;
                int start = startObj;
                while (start < range[2] && matchingRows < MAX_PREFIX_MATCHING_ROWS) {
                    int end = findLineEnd(start);
                    int tab = findTab(start, end);
                    if (tab <= start) break;
                    String key = decode(start, tab);
                    if (!key.startsWith(prefix)) break;

                    List<String> row = candidatesInLine(start, end);
                    for (int rank = 0; rank < row.size() && rank < MAX_PREFIX_CANDIDATES_PER_ROW; rank++) {
                        String candidate = row.get(rank);
                        int[] s = scores.get(candidate);
                        if (s == null) {
                            s = new int[]{range[0], rank, firstSeen++, 0};
                            scores.put(candidate, s);
                        }
                        s[3]++;
                        s[0] = Math.min(s[0], range[0]);
                        s[1] = Math.min(s[1], rank);
                    }
                    matchingRows++;
                    start = nextLineStart(end);
                }
                if (matchingRows >= MAX_PREFIX_MATCHING_ROWS) break;
            }

            List<Map.Entry<String, int[]>> entries = new ArrayList<>(scores.entrySet());
            Collections.sort(entries, (a, b) -> {
                int[] x = a.getValue(), y = b.getValue();
                if (x[0] != y[0]) return Integer.compare(x[0], y[0]);
                if (x[3] != y[3]) return Integer.compare(y[3], x[3]);
                if (x[1] != y[1]) return Integer.compare(x[1], y[1]);
                return Integer.compare(x[2], y[2]);
            });
            List<String> candidates = new ArrayList<>();
            for (Map.Entry<String, int[]> e : entries) {
                if (candidates.size() >= limit) break;
                candidates.add(e.getKey());
            }
            candidates = Collections.unmodifiableList(candidates);
            synchronized (cacheLock) {
                prefixCandidateCache.put(cacheKey, candidates);
            }
            return candidates;
        }

        private int[] findLine(String target) {
            int low = dataStart;
            int high = byteCount;
            while (low < high) {
                int middle = low + (high - low) / 2;
                int lineStart = findLineStart(middle, low);
                int lineEnd = findLineEnd(lineStart);
                int tab = findTab(lineStart, lineEnd);
                if (tab <= lineStart) return null;
                int cmp = compareKeys(decode(lineStart, tab), target);
                if (cmp < 0) low = nextLineStart(lineEnd);
                else if (cmp > 0) high = lineStart;
                else return new int[]{lineStart, lineEnd};
            }
            return null;
        }

        private List<int[]> lengthRanges() {
            List<int[]> ranges = lengthRanges;
            if (ranges != null) return ranges;
            synchronized (this) {
                if (lengthRanges == null) lengthRanges = buildLengthRanges();
                return lengthRanges;
            }
        }

        private List<int[]> buildLengthRanges() {
            List<int[]> result = new ArrayList<>();
            int start = dataStart;
            while (start < byteCount) {
                int end = findLineEnd(start);
                int tab = findTab(start, end);
                if (tab <= start) break;
                String key = decode(start, tab);
                int length = key.codePointCount(0, key.length());
                // 各列先依長度排序：用二分搜尋找下一個長度的邊界，而不是逐列解碼。
                int low = nextLineStart(end);
                int high = byteCount;
                while (low < high) {
                    int lineStart = findLineStart(low + (high - low) / 2, low);
                    int lineEnd = findLineEnd(lineStart);
                    int lineTab = findTab(lineStart, lineEnd);
                    if (lineTab <= lineStart) throw new IllegalStateException("Malformed dictionary row");
                    String middleKey = decode(lineStart, lineTab);
                    if (middleKey.codePointCount(0, middleKey.length()) <= length) {
                        low = nextLineStart(lineEnd);
                    } else {
                        high = lineStart;
                    }
                }
                result.add(new int[]{length, start, low});
                start = low;
            }
            return Collections.unmodifiableList(result);
        }

        private Integer findFirstPrefixLine(String prefix, int[] range) {
            int low = range[1];
            int high = range[2];
            while (low < high) {
                int middle = low + (high - low) / 2;
                int lineStart = findLineStart(middle, low);
                int lineEnd = findLineEnd(lineStart);
                int tab = findTab(lineStart, lineEnd);
                if (tab <= lineStart) return null;
                if (compareKeyToPrefix(decode(lineStart, tab), prefix) < 0) {
                    low = nextLineStart(lineEnd);
                } else {
                    high = lineStart;
                }
            }
            return low < range[2] ? low : null;
        }

        private List<String> candidatesInLine(int start, int end) {
            int tab = findTab(start, end);
            if (tab <= start || tab >= end - 1) return Collections.emptyList();
            String[] parts = decode(tab + 1, contentEnd(start, end)).split(" ");
            LinkedHashSet<String> out = new LinkedHashSet<>();
            for (String p : parts) {
                if (!p.trim().isEmpty()) out.add(p);
            }
            return Collections.unmodifiableList(new ArrayList<>(out));
        }

        private int findDataStart() {
            int start = 0;
            while (start < byteCount) {
                int end = findLineEnd(start);
                if (!isHeaderOrBlank(start, end)) return start;
                start = nextLineStart(end);
            }
            return byteCount;
        }

        private boolean isHeaderOrBlank(int start, int end) {
            if (start >= end) return true;
            if (byteAt(start) == COMMENT) return true;
            for (int i = start; i < end; i++) {
                int b = byteAt(i);
                if (b != SPACE && b != TAB && b != CARRIAGE_RETURN) return false;
            }
            return true;
        }

        private int findLineStart(int index, int floor) {
            int cursor = Math.min(index, byteCount - 1);
            while (cursor > floor && byteAt(cursor - 1) != LINE_FEED) cursor--;
            return cursor;
        }

        private int findLineEnd(int start) {
            int cursor = start;
            while (cursor < byteCount && byteAt(cursor) != LINE_FEED) cursor++;
            return cursor;
        }

        private int nextLineStart(int lineEnd) {
            return lineEnd < byteCount ? lineEnd + 1 : byteCount;
        }

        private int findTab(int start, int end) {
            for (int i = start; i < end; i++) {
                if (byteAt(i) == TAB) return i;
            }
            return -1;
        }

        private int contentEnd(int start, int end) {
            return (end > start && byteAt(end - 1) == CARRIAGE_RETURN) ? end - 1 : end;
        }

        private String decode(int start, int end) {
            if (end <= start) return "";
            byte[] result = new byte[end - start];
            for (int i = 0; i < result.length; i++) result[i] = bytes.get(start + i);
            return new String(result, StandardCharsets.UTF_8);
        }

        private int byteAt(int index) {
            return bytes.get(index) & 0xFF;
        }

        private static int compareKeyToPrefix(String key, String prefix) {
            int ki = 0, pi = 0;
            while (ki < key.length() && pi < prefix.length()) {
                int kc = key.codePointAt(ki);
                int pc = prefix.codePointAt(pi);
                if (kc != pc) return Integer.compare(kc, pc);
                ki += Character.charCount(kc);
                pi += Character.charCount(pc);
            }
            return pi == prefix.length() ? 0 : -1;
        }

        static int compareKeys(String left, String right) {
            int lengthCmp = Integer.compare(left.codePointCount(0, left.length()), right.codePointCount(0, right.length()));
            if (lengthCmp != 0) return lengthCmp;
            int li = 0, ri = 0;
            while (li < left.length() && ri < right.length()) {
                int lc = left.codePointAt(li);
                int rc = right.codePointAt(ri);
                if (lc != rc) return Integer.compare(lc, rc);
                li += Character.charCount(lc);
                ri += Character.charCount(rc);
            }
            return 0;
        }
    }
}
