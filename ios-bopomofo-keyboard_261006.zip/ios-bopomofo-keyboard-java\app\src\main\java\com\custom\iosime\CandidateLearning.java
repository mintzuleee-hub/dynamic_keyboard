package com.custom.iosime;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 選字學習（搬運自 dynamic-zhuyin-keyboard 的 UserDictionaryStore 學習表 + CandidateRanking，改寫為 Java）。
 * 記錄「某個讀音選了哪個字詞幾次」，排序時讓常選的往前；也用來記住「某詞後面常接什麼詞」。
 * 只存在本機 SQLite（candidate_learning.db），不會上傳。
 */
final class CandidateLearning extends SQLiteOpenHelper {

    private static final String DB_NAME = "candidate_learning.db";
    private static final int DB_VERSION = 1;
    private static final String TABLE = "candidate_learning";
    private static final String COL_READING = "reading";
    private static final String COL_WORD = "word";
    private static final String COL_COUNT = "selection_count";
    private static final String COL_UPDATED_AT = "updated_at";

    CandidateLearning(Context context) {
        super(context.getApplicationContext(), DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE + " ("
                + COL_READING + " TEXT NOT NULL, "
                + COL_WORD + " TEXT NOT NULL, "
                + COL_COUNT + " INTEGER NOT NULL DEFAULT 0, "
                + COL_UPDATED_AT + " INTEGER NOT NULL, "
                + "PRIMARY KEY(" + COL_READING + ", " + COL_WORD + "))");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_candidate_learning_updated ON "
                + TABLE + "(" + COL_UPDATED_AT + " DESC)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);
    }

    void recordSelection(String reading, String word) {
        if (reading == null || word == null) return;
        String r = reading.trim();
        String w = word.trim();
        if (r.isEmpty() || w.isEmpty()) return;

        long now = System.currentTimeMillis();
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            values.put(COL_READING, r);
            values.put(COL_WORD, w);
            values.put(COL_COUNT, 0);
            values.put(COL_UPDATED_AT, now);
            db.insertWithOnConflict(TABLE, null, values, SQLiteDatabase.CONFLICT_IGNORE);
            db.execSQL("UPDATE " + TABLE + " SET " + COL_COUNT + " = MIN(" + COL_COUNT + " + 1, 2147483647), "
                            + COL_UPDATED_AT + " = ? WHERE " + COL_READING + " = ? AND " + COL_WORD + " = ?",
                    new Object[]{now, r, w});
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    Map<String, Integer> getLearningCounts(List<String> readings) {
        Map<String, Integer> result = new HashMap<>();
        List<String> selected = cleanReadings(readings);
        if (selected.isEmpty()) return result;
        try (Cursor c = getReadableDatabase().query(TABLE, new String[]{COL_WORD, COL_COUNT},
                COL_READING + " IN (" + placeholders(selected.size()) + ")",
                selected.toArray(new String[0]), null, null, null)) {
            while (c.moveToNext()) {
                String word = c.getString(0);
                long combined = (long) (result.containsKey(word) ? result.get(word) : 0) + c.getInt(1);
                result.put(word, (int) Math.min(combined, Integer.MAX_VALUE));
            }
        }
        return result;
    }

    List<String> getLearnedCandidates(List<String> readings) {
        List<String> selected = cleanReadings(readings);
        if (selected.isEmpty()) return Collections.emptyList();
        final Map<String, long[]> agg = new LinkedHashMap<>(); // {count, updatedAt}
        try (Cursor c = getReadableDatabase().query(TABLE, new String[]{COL_WORD, COL_COUNT, COL_UPDATED_AT},
                COL_READING + " IN (" + placeholders(selected.size()) + ")",
                selected.toArray(new String[0]), null, null, null)) {
            while (c.moveToNext()) {
                String word = c.getString(0);
                long[] a = agg.get(word);
                if (a == null) { a = new long[]{0, 0}; agg.put(word, a); }
                a[0] = Math.min(a[0] + c.getInt(1), Integer.MAX_VALUE);
                a[1] = Math.max(a[1], c.getLong(2));
            }
        }
        List<String> words = new ArrayList<>(agg.keySet());
        Collections.sort(words, (x, y) -> {
            long[] a = agg.get(x), b = agg.get(y);
            if (a[0] != b[0]) return Long.compare(b[0], a[0]);
            if (a[1] != b[1]) return Long.compare(b[1], a[1]);
            return x.compareTo(y);
        });
        return words;
    }

    private static List<String> cleanReadings(List<String> readings) {
        LinkedHashSet<String> set = new LinkedHashSet<>();
        for (String r : readings) if (r != null && !r.trim().isEmpty()) set.add(r);
        return new ArrayList<>(set);
    }

    private static String placeholders(int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) sb.append(i == 0 ? "?" : ",?");
        return sb.toString();
    }

    /** 排序：手動詞 → 字典沒有、但學過的詞 → 字典候選（學過的次數會把它往前推）。 */
    static List<String> order(List<String> manualCandidates, List<String> dictionaryCandidates,
                              final Map<String, Integer> learnedCounts, List<String> learnedCandidates) {
        List<String> manual = new ArrayList<>(new LinkedHashSet<>(manualCandidates));
        Set<String> manualSet = new HashSet<>(manual);
        Set<String> dictionarySet = new HashSet<>(dictionaryCandidates);

        final List<String> learnedPool = new ArrayList<>();
        for (String w : new LinkedHashSet<>(learnedCandidates)) {
            if (!manualSet.contains(w) && !dictionarySet.contains(w)) learnedPool.add(w);
        }
        List<Integer> li = indices(learnedPool.size());
        Collections.sort(li, (a, b) -> {
            int ca = count(learnedCounts, learnedPool.get(a)), cb = count(learnedCounts, learnedPool.get(b));
            if (ca != cb) return Integer.compare(cb, ca);
            return Integer.compare(a, b);
        });
        List<String> learned = new ArrayList<>();
        for (int i : li) learned.add(learnedPool.get(i));

        Set<String> prioritized = new HashSet<>(manualSet);
        prioritized.addAll(learned);
        final List<String> dictPool = new ArrayList<>();
        for (String w : new LinkedHashSet<>(dictionaryCandidates)) if (!prioritized.contains(w)) dictPool.add(w);
        List<Integer> di = indices(dictPool.size());
        Collections.sort(di, (a, b) -> {
            long sa = (long) a - count(learnedCounts, dictPool.get(a));
            long sb = (long) b - count(learnedCounts, dictPool.get(b));
            if (sa != sb) return Long.compare(sa, sb);
            return Integer.compare(a, b);
        });

        List<String> out = new ArrayList<>(manual);
        out.addAll(learned);
        for (int i : di) out.add(dictPool.get(i));
        return out;
    }

    private static int count(Map<String, Integer> counts, String w) {
        Integer c = counts.get(w);
        return c == null ? 0 : c;
    }

    private static List<Integer> indices(int n) {
        List<Integer> l = new ArrayList<>(n);
        for (int i = 0; i < n; i++) l.add(i);
        return l;
    }
}
