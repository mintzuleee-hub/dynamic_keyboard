package com.custom.iosime;

import android.content.Context;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

/**
 * 選字後的「下一個詞」聯想（搬運自 dynamic-zhuyin-keyboard 的 NextWordTable + NextWordSuggestions，改寫為 Java）。
 * 內建表 assets/next_word.tsv 由 McBopomofo phrase.occ（MIT）產生。
 */
final class NextWordTable {

    private static final String ASSET_NAME = "next_word.tsv";
    private static final int MAX_SUGGESTIONS = 8;

    /** 沒有其他東西可聯想時，顯示常用標點。 */
    static final List<String> PUNCTUATION_FALLBACK = Collections.unmodifiableList(Arrays.asList("，", "。", "！", "？"));

    private static final Map<String, List<String>> COMMON = new HashMap<>();
    static {
        COMMON.put("你好", Arrays.asList("嗎", "世界"));
        COMMON.put("謝謝", Arrays.asList("你", "大家", "幫忙"));
        COMMON.put("早安", Arrays.asList("你好", "大家"));
        COMMON.put("晚安", Arrays.asList("好夢"));
        COMMON.put("今天", Arrays.asList("晚上", "下午", "天氣"));
        COMMON.put("明天", Arrays.asList("早上", "見"));
        COMMON.put("我", Arrays.asList("想", "是", "要", "的"));
        COMMON.put("你", Arrays.asList("好", "是", "的"));
        COMMON.put("我們", Arrays.asList("一起", "可以"));
        COMMON.put("可以", Arrays.asList("嗎", "幫忙"));
        COMMON.put("生日", Arrays.asList("快樂"));
        COMMON.put("新年", Arrays.asList("快樂"));
        COMMON.put("台灣", Arrays.asList("人", "美食"));
    }

    private static volatile Map<String, List<String>> table;

    private NextWordTable() {}

    static String learningKey(String word) {
        return "@next:" + word;
    }

    /** 只對中文字（CJK 統一表意文字）做聯想。 */
    static boolean eligible(String word) {
        if (word == null || word.isEmpty() || word.length() > 64) return false;
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            if (c < '㐀' || c > '鿿') return false;
        }
        return true;
    }

    /** 在背景執行緒呼叫：解析內建表。 */
    static synchronized void load(Context context) {
        if (table != null) return;
        Map<String, List<String>> parsed = new HashMap<>();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(context.getAssets().open(ASSET_NAME), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.isEmpty() || line.startsWith("#")) continue;
                int tab = line.indexOf('\t');
                if (tab <= 0) continue;
                List<String> values = new ArrayList<>();
                for (String v : line.substring(tab + 1).split(" ")) if (!v.isEmpty()) values.add(v);
                if (!values.isEmpty()) parsed.put(line.substring(0, tab), values);
            }
        } catch (Exception e) {
            android.util.Log.w("IosIME", "無法載入 " + ASSET_NAME, e);
        }
        table = parsed;
    }

    /** 內建表：用整個詞、再退到最後兩字、最後一字去查。 */
    static List<String> continuations(String previous) {
        Map<String, List<String>> t = table;
        if (t == null) return Collections.emptyList();
        LinkedHashSet<String> results = new LinkedHashSet<>();
        for (int size = Math.min(previous.length(), 3); size >= 1; size--) {
            List<String> v = t.get(previous.substring(previous.length() - size));
            if (v != null) results.addAll(v);
            if (results.size() >= MAX_SUGGESTIONS) break;
        }
        List<String> out = new ArrayList<>(results);
        return out.size() > MAX_SUGGESTIONS ? out.subList(0, MAX_SUGGESTIONS) : out;
    }

    /** 順序：個人學到的 → 內建常用短語 → 內建詞頻表。 */
    static List<String> suggest(String previous, List<String> learned) {
        if (!eligible(previous)) return Collections.emptyList();
        LinkedHashSet<String> out = new LinkedHashSet<>();
        for (String w : learned) if (eligible(w)) out.add(w);
        List<String> common = COMMON.get(previous);
        if (common != null) out.addAll(common);
        for (String w : continuations(previous)) if (eligible(w)) out.add(w);
        List<String> list = new ArrayList<>(out);
        return list.size() > MAX_SUGGESTIONS ? list.subList(0, MAX_SUGGESTIONS) : list;
    }
}
