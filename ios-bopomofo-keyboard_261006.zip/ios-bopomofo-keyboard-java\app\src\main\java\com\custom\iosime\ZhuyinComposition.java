package com.custom.iosime;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * 選字邏輯（搬運自 dynamic-zhuyin-keyboard 的 ZhuyinComposition，改寫為 Java）。
 *
 * 流程：
 * 1. 把整段注音切成音節（遇到聲調就結束；沒有聲調的連續注音用字典判斷最長合法音節）。
 * 2. 整段讀音直接查得到詞 → 用整段結果。
 * 3. 查不到 → 以「每個音節邊界」做有上限的 beam search，盡量用較長的詞組成整句。
 * 4. 仍然沒有 → 退回到較短的開頭讀音、或尚未打完聲調時的前綴候選。
 * 並且一律把「第一個音節的單字」插在第一名後面，方便只想選一個字時修正。
 */
final class ZhuyinComposition {

    private static final int MAX_SYLLABLE_LENGTH = 3;
    private static final int MAX_FALLBACK_CANDIDATES = 9;
    static final String TONE_CHARS = "ˉ˙ˊˇˋ";

    private ZhuyinComposition() {}

    static boolean isTone(char c) {
        return TONE_CHARS.indexOf(c) >= 0;
    }

    static final class Segment {
        final String text;
        final int start;
        final int end;
        final boolean hasTone;

        Segment(String text, int start, int end, boolean hasTone) {
            this.text = text;
            this.start = start;
            this.end = end;
            this.hasTone = hasTone;
        }
    }

    static final class Choice {
        final String text;
        final String reading;
        final int start;
        final int end;
        final boolean provisional;

        Choice(String text, String reading, int start, int end, boolean provisional) {
            this.text = text;
            this.reading = reading;
            this.start = start;
            this.end = end;
            this.provisional = provisional;
        }
    }

    static final class Match {
        final String reading;
        final int start;
        final int end;
        final boolean provisional;
        final List<Choice> choices;

        Match(String reading, List<String> candidates, int start, int end, boolean provisional) {
            this.reading = reading;
            this.start = start;
            this.end = end;
            this.provisional = provisional;
            List<Choice> list = new ArrayList<>();
            for (String c : candidates) list.add(new Choice(c, reading, start, end, provisional));
            this.choices = list;
        }

        Match(Match base, List<Choice> choices) {
            this.reading = base.reading;
            this.start = base.start;
            this.end = base.end;
            this.provisional = base.provisional;
            this.choices = choices;
        }
    }

    static List<Segment> splitSegments(String text, Predicate<String> isKnownUntonedSyllable) {
        List<Segment> result = new ArrayList<>();
        if (text == null || text.isEmpty()) return result;
        int index = 0;
        while (index < text.length()) {
            if (isTone(text.charAt(index))) {
                result.add(new Segment(text.substring(index, index + 1), index, index + 1, true));
                index++;
                continue;
            }
            int runStart = index;
            while (index < text.length() && !isTone(text.charAt(index))) index++;
            splitBaseRun(text, runStart, index, result, isKnownUntonedSyllable);

            if (index < text.length() && isTone(text.charAt(index)) && !result.isEmpty()) {
                Segment last = result.remove(result.size() - 1);
                result.add(new Segment(text.substring(last.start, index + 1), last.start, index + 1, true));
                index++;
            }
        }
        return result;
    }

    static Match resolveLeadingCandidates(
            String raw,
            List<Segment> segments,
            Function<String, List<String>> preferredPrefixCandidatesForReading,
            Function<String, List<String>> prefixCandidatesForReading,
            Function<String, List<String>> candidatesForReading) {
        if (raw == null || raw.isEmpty()) return null;

        List<Integer> candidateEnds = new ArrayList<>();
        {
            LinkedHashSet<Integer> ends = new LinkedHashSet<>();
            for (Segment s : segments) ends.add(s.end);
            ends.add(raw.length());
            for (Integer e : ends) if (e >= 1 && e <= raw.length()) candidateEnds.add(e);
            Collections.sort(candidateEnds, Collections.reverseOrder());
        }

        List<String> fullCandidates = candidatesForReading.apply(raw);
        if (!fullCandidates.isEmpty()) {
            return withLeadingCharacterAlternatives(
                    new Match(raw, fullCandidates, 0, raw.length(), false), raw, segments, candidatesForReading);
        }

        List<String> composed = composeSyllableCandidates(raw, segments,
                preferredPrefixCandidatesForReading, candidatesForReading, s -> Collections.<String>emptyList());
        if (!composed.isEmpty()) {
            return withLeadingCharacterAlternatives(
                    new Match(raw, composed, 0, raw.length(), false), raw, segments, candidatesForReading);
        }

        // 整句組不出來時，保留手動修正開頭片語的能力。
        List<Integer> phrasePrefixEnds = new ArrayList<>();
        {
            LinkedHashSet<Integer> ends = new LinkedHashSet<>();
            for (int i = 1; i < segments.size(); i++) ends.add(segments.get(i).end);
            for (Integer e : ends) if (e >= 1 && e < raw.length()) phrasePrefixEnds.add(e);
            Collections.sort(phrasePrefixEnds, Collections.reverseOrder());
        }
        for (int end : phrasePrefixEnds) {
            String reading = raw.substring(0, end);
            if (!preferredPrefixCandidatesForReading.apply(reading).isEmpty()) {
                List<String> candidates = candidatesForReading.apply(reading);
                return withLeadingCharacterAlternatives(
                        new Match(reading, candidates, 0, end, false), raw, segments, candidatesForReading);
            }
        }

        boolean anyUntoned = false;
        for (Segment s : segments) if (!s.hasTone) { anyUntoned = true; break; }
        if (anyUntoned) {
            List<String> prefixCandidates = prioritizePrefixCandidates(
                    prefixCandidatesForReading.apply(raw), raw, segments, candidatesForReading);
            if (!prefixCandidates.isEmpty()) {
                return withLeadingCharacterAlternatives(
                        new Match(raw, prefixCandidates, 0, raw.length(), true), raw, segments, candidatesForReading);
            }
            List<String> partial = composeSyllableCandidates(raw, segments,
                    preferredPrefixCandidatesForReading, candidatesForReading, prefixCandidatesForReading);
            if (!partial.isEmpty()) {
                return withLeadingCharacterAlternatives(
                        new Match(raw, partial, 0, raw.length(), true), raw, segments, candidatesForReading);
            }
        }

        for (int end : candidateEnds) {
            if (end >= raw.length()) continue;
            String reading = raw.substring(0, end);
            List<String> candidates = candidatesForReading.apply(reading);
            if (!candidates.isEmpty()) {
                return withLeadingCharacterAlternatives(
                        new Match(reading, candidates, 0, end, false), raw, segments, candidatesForReading);
            }
        }
        return null;
    }

    private static Match withLeadingCharacterAlternatives(
            Match match, String raw, List<Segment> segments,
            Function<String, List<String>> candidatesForReading) {
        if (match.start != 0 || match.choices.isEmpty()) return match;
        Segment leading = null;
        for (Segment s : segments) {
            if (s.start == 0 && s.end >= 1 && s.end < match.end) { leading = s; break; }
        }
        if (leading == null) return match;
        String leadingReading = raw.substring(0, leading.end);
        List<Choice> leadingChoices = new ArrayList<>();
        for (String c : candidatesForReading.apply(leadingReading)) {
            if (isSingleCodePoint(c)) leadingChoices.add(new Choice(c, leadingReading, 0, leading.end, false));
        }
        if (leadingChoices.isEmpty()) return match;

        List<Choice> mixed = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        List<Choice> ordered = new ArrayList<>();
        ordered.add(match.choices.get(0));
        ordered.addAll(leadingChoices);
        ordered.addAll(match.choices.subList(1, match.choices.size()));
        for (Choice c : ordered) {
            if (seen.add(c.text + '\u0000' + c.start + '\u0000' + c.end)) mixed.add(c);
        }
        return new Match(match, mixed);
    }

    private static List<String> prioritizePrefixCandidates(
            List<String> candidates, String raw, List<Segment> segments,
            Function<String, List<String>> candidatesForReading) {
        if (candidates.size() < 2) return candidates;
        Segment leading = null;
        for (Segment s : segments) {
            if (s.start == 0 && s.end < raw.length()) { leading = s; break; }
        }
        if (leading == null) return candidates;
        List<String> leadingChoices = new ArrayList<>();
        for (String c : candidatesForReading.apply(leading.text)) if (isSingleCodePoint(c)) leadingChoices.add(c);
        if (leadingChoices.isEmpty()) return candidates;

        List<Integer> idx = new ArrayList<>();
        for (int i = 0; i < candidates.size(); i++) idx.add(i);
        final List<String> lc = leadingChoices;
        Collections.sort(idx, (a, b) -> {
            int ra = leadingRank(lc, candidates.get(a));
            int rb = leadingRank(lc, candidates.get(b));
            if (ra != rb) return Integer.compare(ra, rb);
            return Integer.compare(a, b);
        });
        List<String> out = new ArrayList<>();
        for (int i : idx) out.add(candidates.get(i));
        return out;
    }

    private static int leadingRank(List<String> leadingChoices, String candidate) {
        for (int i = 0; i < leadingChoices.size(); i++) {
            if (candidate.startsWith(leadingChoices.get(i))) return i;
        }
        return Integer.MAX_VALUE;
    }

    private static final class Path {
        final String text;
        final int cost;

        Path(String text, int cost) {
            this.text = text;
            this.cost = cost;
        }
    }

    private static final Comparator<Path> PATH_ORDER = (a, b) -> {
        if (a.cost != b.cost) return Integer.compare(a.cost, b.cost);
        return a.text.compareTo(b.text);
    };

    private static List<Path> sortedDistinct(List<Path> paths, int limit) {
        List<Path> sorted = new ArrayList<>(paths);
        Collections.sort(sorted, PATH_ORDER);
        LinkedHashMap<String, Path> unique = new LinkedHashMap<>();
        for (Path p : sorted) {
            if (!unique.containsKey(p.text)) unique.put(p.text, p);
            if (unique.size() >= limit) break;
        }
        return new ArrayList<>(unique.values());
    }

    // 在每個音節邊界做有上限的 beam search；輸入長度不設上限。
    // 候選順序已經包含內建詞頻與（允許時的）學習結果。
    private static List<String> composeSyllableCandidates(
            String raw, List<Segment> segments,
            Function<String, List<String>> preferredCandidates,
            Function<String, List<String>> candidatesForReading,
            Function<String, List<String>> partialCandidates) {
        if (segments.size() < 2 || segments.get(0).start != 0
                || segments.get(segments.size() - 1).end != raw.length()) return Collections.emptyList();
        for (int i = 0; i < segments.size() - 1; i++) {
            if (!segments.get(i).hasTone) return Collections.emptyList();
        }

        int n = segments.size();
        List<List<Path>> beams = new ArrayList<>();
        for (int i = 0; i <= n; i++) beams.add(new ArrayList<>());
        beams.get(0).add(new Path("", 0));

        for (int start = 0; start < n; start++) {
            if (beams.get(start).isEmpty()) continue;
            List<Path> prefixes = sortedDistinct(beams.get(start), MAX_FALLBACK_CANDIDATES);
            for (int end = start + 1; end <= Math.min(n, start + 16); end++) {
                int span = end - start;
                String reading = raw.substring(segments.get(start).start, segments.get(end - 1).end);
                StringBuilder normalizedSb = new StringBuilder();
                for (int i = start; i < end; i++) {
                    String sandhi = toneSandhiReading(segments.get(i), i + 1 < n ? segments.get(i + 1) : null);
                    normalizedSb.append(sandhi != null ? sandhi : segments.get(i).text);
                }
                String normalized = normalizedSb.toString();
                Set<String> preferred = new HashSet<>(preferredCandidates.apply(reading));
                boolean incomplete = end == n && !segments.get(n - 1).hasTone;
                List<String> normalizedChoices = incomplete
                        ? partialCandidates.apply(reading)
                        : candidatesForReading.apply(normalized);

                LinkedHashSet<String> merged = new LinkedHashSet<>(normalizedChoices);
                if (!normalized.equals(reading)) merged.addAll(candidatesForReading.apply(reading));
                List<String> choices = new ArrayList<>();
                for (String c : merged) {
                    if (span > 1 || isSingleCodePoint(c)) choices.add(c);
                    if (choices.size() >= 4) break;
                }

                Set<String> normalizedSet = new HashSet<>(normalizedChoices);
                for (int rank = 0; rank < choices.size(); rank++) {
                    String choice = choices.get(rank);
                    // 詞的邊界越少越好（勝過單純逐字拼接）；加分有上限，單一學習詞不會壓過整句。
                    int sandhiPenalty = (!normalized.equals(reading) && !normalizedSet.contains(choice)
                            && !preferred.contains(choice)) ? 16 : 0;
                    int edgeCost = 12 + rank * 2 - Math.min(span, 8) * 2 + sandhiPenalty
                            - (preferred.contains(choice) ? 6 : 0);
                    for (Path prefix : prefixes) {
                        beams.get(end).add(new Path(prefix.text + choice, prefix.cost + edgeCost));
                    }
                }
                if (beams.get(end).size() > MAX_FALLBACK_CANDIDATES) {
                    List<Path> best = sortedDistinct(beams.get(end), MAX_FALLBACK_CANDIDATES);
                    beams.get(end).clear();
                    beams.get(end).addAll(best);
                }
            }
            beams.get(start).clear();
        }
        List<String> out = new ArrayList<>();
        for (Path p : sortedDistinct(beams.get(n), Integer.MAX_VALUE)) out.add(p.text);
        return out;
    }

    // 變調：「一」「不」在特定聲調前的讀音
    private static String toneSandhiReading(Segment segment, Segment next) {
        if (segment.text.isEmpty() || next == null || next.text.isEmpty()) return null;
        char currentTone = segment.text.charAt(segment.text.length() - 1);
        char nextTone = next.text.charAt(next.text.length() - 1);
        if (!isTone(currentTone) || !isTone(nextTone)) return null;
        String base = segment.text.substring(0, segment.text.length() - 1);
        if (base.equals("ㄧ") && currentTone == 'ˊ' && nextTone == 'ˋ') return "ㄧˉ";
        if (base.equals("ㄧ") && currentTone == 'ˋ' && (nextTone == 'ˉ' || nextTone == 'ˊ' || nextTone == 'ˇ')) return "ㄧˉ";
        if (base.equals("ㄅㄨ") && currentTone == 'ˊ' && nextTone == 'ˋ') return "ㄅㄨˋ";
        return null;
    }

    static boolean isSingleCodePoint(String value) {
        return value != null && !value.isEmpty() && value.codePointCount(0, value.length()) == 1;
    }

    private static void splitBaseRun(String text, int start, int end, List<Segment> result,
                                     Predicate<String> isKnownUntonedSyllable) {
        int position = start;
        while (position < end) {
            int foundEnd = -1;
            for (int length = Math.min(MAX_SYLLABLE_LENGTH, end - position); length >= 1; length--) {
                if (isKnownUntonedSyllable.test(text.substring(position, position + length))) {
                    foundEnd = position + length;
                    break;
                }
            }
            if (foundEnd < 0) foundEnd = position + 1;
            result.add(new Segment(text.substring(position, foundEnd), position, foundEnd, false));
            position = foundEnd;
        }
    }
}
