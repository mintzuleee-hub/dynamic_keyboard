# 第三方來源與授權聲明

## 中文選字邏輯

`ZhuyinDictionary.java`、`ZhuyinComposition.java`、`CandidateLearning.java`、`NextWordTable.java`
由 dynamic-zhuyin-keyboard 專案（Apache License 2.0）的 Kotlin 原始碼改寫為 Java 移植而來：
ZhuyinDictionary / SortedTsvDictionary、ZhuyinComposition、UserDictionaryStore（學習表部分）、
CandidateRanking、NextWordTable、NextWordSuggestions。

## 打包的字典資料

### `app/src/main/assets/zhuyin_cedict.tsv`
- 由 CC-CEDICT 轉換為注音，授權：Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)
  - https://cc-cedict.org/ ／ https://creativecommons.org/licenses/by-sa/4.0/
- 合併 McBopomofo 片語讀音（BPMFMappings.txt）並以 phrase.occ 詞頻排序，授權：MIT
  - https://github.com/openvanilla/McBopomofo （commit 14f672cd9296deb4ff87034b05003b15a1e796f5）
  - Copyright (c) 2011-2026 Mengjuei Hsieh et al.
- 完整來源與授權說明見 `app/src/main/assets/zhuyin_cedict_LICENSE.txt`。
- 重新散布此衍生資料時，請保留上述標示，並以相容授權（CC BY-SA 4.0）處理該資料檔。

### `app/src/main/assets/next_word.tsv`
- 由 McBopomofo phrase.occ（MIT）產生的「下一個詞」聯想表。
